//
//  UserKitIdentity.h
//  UserKitIdentity
//
//  Created by Huy Nguyen on 1/17/17.
//  Copyright © 2017 mStage. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UserKitIdentity.
FOUNDATION_EXPORT double UserKitIdentityVersionNumber;

//! Project version string for UserKitIdentity.
FOUNDATION_EXPORT const unsigned char UserKitIdentityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UserKitIdentity/PublicHeader.h>


