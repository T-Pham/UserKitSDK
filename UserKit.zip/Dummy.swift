import Foundation

class Dummy {}
