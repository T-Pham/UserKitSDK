//
//  UserKitSDK.h
//  UserKitSDK
//
//  Created by Huy Nguyen on 1/17/17.
//  Copyright © 2017 mStage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Firebase.h"

//! Project version number for UserKitSDK.
FOUNDATION_EXPORT double UserKitSDKVersionNumber;

//! Project version string for UserKitSDK.
FOUNDATION_EXPORT const unsigned char UserKitSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UserKitSDK/PublicHeader.h>


